package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.RowFilter;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Order extends JFrame {

	private JPanel contentPane;
	private JTextField txtProductname;
	private JTextField txtQuantity;
	private JTextField txtAmount;
	private int totalPrice;
	private JButton btnOrder;
	private DefaultTableModel model;
	private JLabel lblProductNameSummary;
	private JLabel lblProductQuantitySummary;
	private JLabel lblTotalSummary;
	private JLabel lblTime;
	private JLabel lblbg;
	private int quantity;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Order frame = new Order();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
				
	/**
	 * Create the frame.
	 */
	public Order() {
		setBackground(new Color(255, 255, 255));
		setTitle("Eve's Express - Order Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 964, 619);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 255, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		
		model = new DefaultTableModel();
        JTable tblData = new JTable(model);

        // Add columns to the table model
        model.addColumn("Product ID");
        model.addColumn("Product Name");
        model.addColumn("Quantity");
        model.addColumn("Price in Php");
        model.addColumn("Unit");
        model.addColumn("Category");
        
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
            String selectQuery = "SELECT * FROM products";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    // Retrieve data from the result set
                    int productId = resultSet.getInt("product_id");
                    String productName = resultSet.getString("product_name");
                    quantity = resultSet.getInt("quantity");
                    int price = resultSet.getInt("price_php_perPiece");
                    String unit = resultSet.getString("unit");
                    String category = resultSet.getString("category");

                    // Add a row to the table model
                    model.addRow(new Object[]{productId, productName, quantity, price, unit, category});
                }
            }

            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(tblData.getModel());
        tblData.setRowSorter(rowSorter);
        
        JScrollPane scrollPane = new JScrollPane(tblData);
        scrollPane.setBounds(85, 80, 490, 425);
        contentPane.add(scrollPane);
        
        JLabel lblProducts = new JLabel("ORDER PRODUCTS");
        scrollPane.setColumnHeaderView(lblProducts);
        lblProducts.setFont(new Font("Tahoma", Font.PLAIN, 19));
        
        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(new Color(51, 179, 100));
        btnRefresh.setFont(new Font("Tahoma", Font.PLAIN, 15));
        btnRefresh.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        		refreshTableData();
        	}
        });
        btnRefresh.setBounds(330, 520, 129, 42);
        contentPane.add(btnRefresh);
        
        JButton btnBack = new JButton("Back");
        btnBack.setBackground(new Color(51, 179, 100));
        btnBack.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		dispose();
        	}
        });
        btnBack.setFont(new Font("Tahoma", Font.PLAIN, 14));
        btnBack.setBounds(70, 540, 67, 31);
        contentPane.add(btnBack);
        Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/orderbg.png")).getImage();
        
        txtProductname = new JTextField();
        txtProductname.setBounds(727, 80, 119, 30);
        contentPane.add(txtProductname);
        txtProductname.setColumns(10);
        
        txtQuantity = new JTextField();
        txtQuantity.setBounds(727, 121, 119, 30);
        contentPane.add(txtQuantity);
        txtQuantity.setColumns(10);
        
        JLabel lblTotal = new JLabel("PHP");
        lblTotal.setBounds(659, 162, 88, 41);
        contentPane.add(lblTotal);
        lblTotal.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        JLabel lblTotalPrice = new JLabel("0");
        lblTotalPrice.setBounds(706, 162, 82, 41);
        contentPane.add(lblTotalPrice);
        lblTotalPrice.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        JButton btnCheckprice = new JButton("CHECK PRICE");
        btnCheckprice.setBackground(new Color(51, 179, 100));
        btnCheckprice.setFont(new Font("Tahoma", Font.PLAIN, 10));
        btnCheckprice.setBounds(748, 162, 107, 30);
        contentPane.add(btnCheckprice);
        
        txtAmount = new JTextField();
        txtAmount.setBounds(727, 212, 119, 30);
        contentPane.add(txtAmount);
        txtAmount.setColumns(10);
        
        lblTime = new JLabel("-");
        lblTime.setBounds(728, 378, 140, 21);
        contentPane.add(lblTime);
        lblTime.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        lblProductNameSummary = new JLabel("-");
        lblProductNameSummary.setBounds(731, 415, 123, 21);
        contentPane.add(lblProductNameSummary);
        lblProductNameSummary.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        lblProductQuantitySummary = new JLabel("-");
        lblProductQuantitySummary.setBounds(729, 446, 125, 21);
        contentPane.add(lblProductQuantitySummary);
        lblProductQuantitySummary.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        lblTotalSummary = new JLabel("0");
        lblTotalSummary.setBounds(670, 488, 74, 21);
        contentPane.add(lblTotalSummary);
        lblTotalSummary.setFont(new Font("Tahoma", Font.PLAIN, 17));
        
        JLabel lblbg_1 = new JLabel("");
        lblbg_1.setBounds(0, 0, 948, 589);
        lblbg_1.setIcon(new ImageIcon(bg));
        contentPane.add(lblbg_1);
        
        btnCheckprice.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String productName = txtProductname.getText();
        		String quantityText = txtQuantity.getText();

        		 int userEnteredQuantity = Integer.parseInt(txtQuantity.getText());
        		if (quantityText.isEmpty()) {
                    JOptionPane.showMessageDialog(btnOrder, "Please enter a quantity.");
                    return;  
                }
        		if(userEnteredQuantity > quantity ) {
    				JOptionPane.showMessageDialog(null, "Please enter a valid quantity.");
    				 return; 
    			}
//    			check if user put a positive quantity
    			if(userEnteredQuantity >= 1) {
    				try {
            		    // Retrieve the price_php_perPiece from the database based on the productName
            		    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
            		    String selectQuery = "SELECT price_php_perPiece FROM products WHERE product_name = ?";
            		    
            		    try (PreparedStatement selectStatement = connection.prepareStatement(selectQuery)) {
            		        selectStatement.setString(1, productName);
            		        ResultSet resultSet = selectStatement.executeQuery();
            		               		   
            		        if (resultSet.next()) {
            		            int pricePerPiece = resultSet.getInt("price_php_perPiece");

            		            // Calculate the total price based on the user-input quantity and the price per piece
            		            totalPrice = userEnteredQuantity * pricePerPiece;

            		            // Update the label with the calculated total price
            		            lblTotalPrice.setText(String.valueOf(totalPrice));

            		            // Perform other operations or updates as needed
            		        } else {
            		            // Handle the case where the product name is not found in the database
            		            JOptionPane.showMessageDialog(null, "Product not found in the database.");
            		        }
            		    }

            		    connection.close();

            		} catch (NumberFormatException | SQLException e1) {
            		    // Handle the case where user input is not a valid integer or a database error occurs
            		    JOptionPane.showMessageDialog(null, "Error: Please enter a valid quantity.");
            		}
    			}else JOptionPane.showMessageDialog(null, "Error : Enter a positive quantity.");
        		
        	}
        });
        
        btnOrder = new JButton("ORDER");
        btnOrder.setBackground(new Color(51, 179, 100));
        btnOrder.setBounds(742, 255, 104, 30);
        contentPane.add(btnOrder);
        btnOrder.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    int amount = Integer.parseInt(txtAmount.getText());
                    int change = amount - totalPrice;
                    // Compare the amount entered and the totalPrice

                    if (amount >= totalPrice) {
                    	JOptionPane.showMessageDialog(btnOrder, "Thank you for your order ! your change is " + change);
                    	
                    	updateQuantityInDatabase();
                    	
                    	// Get the current date and time
                        LocalDateTime currentDateTime = LocalDateTime.now();

                        // Format the date and time using a specific pattern
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm");
                        String formattedDateTime = currentDateTime.format(formatter);
                        
                        lblTime.setText(formattedDateTime);

                    	String productName = txtProductname.getText();
                    	int quantity = Integer.parseInt(txtQuantity.getText());
                    	
                    	lblProductNameSummary.setText(productName);
                    	lblProductQuantitySummary.setText(String.valueOf(quantity));
                    	lblTotalSummary.setText(String.valueOf(totalPrice));

;                    } else {
                    	JOptionPane.showMessageDialog(btnOrder, "Please enter a valid amount.");
                    }

                } catch (NumberFormatException ex) {
                    // Handle the case where the amount entered is not a valid integer
                    JOptionPane.showMessageDialog(btnOrder, "Please enter a valid amount.");
                }
            }
        });
        
        btnOrder.setFont(new Font("Tahoma", Font.PLAIN, 17));
       
	}
	//FUNCTION TO UPDATE QUANTITY FROM DATABASE
	private void updateQuantityInDatabase() {
	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
	        String updateQuery = "UPDATE products SET quantity = quantity - ? WHERE product_name = ?";

	        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
	            // Decrement the quantity by the user-entered quantity
	            updateStatement.setInt(1, Integer.parseInt(txtQuantity.getText()));
	            updateStatement.setString(2, txtProductname.getText());
	            
	            // Execute the update query
	            updateStatement.executeUpdate();
	        }

	        connection.close();

	    } catch (NumberFormatException | SQLException e) {
	        // Handle the case where updating the quantity in the database fails
	        JOptionPane.showMessageDialog(btnOrder, "Error: Failed to update quantity in the database.");
	    }
	}
	// Method to update the table model with the latest data from the database
	private void refreshTableData() {
	    // Remove all rows from the table model
	    model.setRowCount(0);

	    try {
	        Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
	        String selectQuery = "SELECT * FROM products";

	        try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
	             ResultSet resultSet = preparedStatement.executeQuery()) {

	            while (resultSet.next()) {
	                // Retrieve data from the result set
	                int productId = resultSet.getInt("product_id");
	                String productName = resultSet.getString("product_name");
	                int quantity = resultSet.getInt("quantity");
	                int price = resultSet.getInt("price_php_perPiece");
	                String unit = resultSet.getString("unit");
	                String category = resultSet.getString("category");

	                // Add a row to the table model
	                model.addRow(new Object[]{productId, productName, quantity, price, unit, category});
	            }
	        }

	        connection.close();
	    } catch (Exception exception) {
	        exception.printStackTrace();
	    }
	    
	}
}
