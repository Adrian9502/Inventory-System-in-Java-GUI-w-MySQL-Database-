package eves_express_inventory_system_w_database;

import javax.swing.border.EmptyBorder;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

import javax.swing.*;
import java.awt.*;
public class Add_new_product extends JFrame {

	private JPanel contentPane;
	private JTextField txtProductName;
	private JTextField txtQuantity;
	private JTextField txtProductID;
	private JTextField txtPrice;
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add_new_product frame = new Add_new_product();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	/**
	 * Create the frame.
	 */
	public Add_new_product() {
		setTitle("Eve's Express - Add New Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 638, 519);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtProductName = new JTextField();
		txtProductName.setBounds(317, 131, 191, 36);
		contentPane.add(txtProductName);
		txtProductName.setColumns(10);
		
		txtQuantity = new JTextField();
		txtQuantity.setBounds(317, 177, 191, 36);
		txtQuantity.setColumns(10);
		contentPane.add(txtQuantity);
		
		txtProductID = new JTextField();
		txtProductID.setBounds(317, 77, 191, 36);
		txtProductID.setColumns(10);
		contentPane.add(txtProductID);
		
		JLabel lblUnit = new JLabel("Unit :");
		lblUnit.setBounds(72, 275, 106, 43);
		lblUnit.setFont(new Font("Tahoma", Font.PLAIN, 15));
		contentPane.add(lblUnit);
		
		JRadioButton rdoKG = new JRadioButton("Kilogram (KG)");
		rdoKG.setBounds(165, 275, 113, 23);
		contentPane.add(rdoKG);
		
		JRadioButton rdoPCS = new JRadioButton("Pieces (PCs)");
		rdoPCS.setBounds(293, 275, 110, 23);
		contentPane.add(rdoPCS);

		ButtonGroup buttonGroup = new ButtonGroup();
        buttonGroup.add(rdoKG);
        buttonGroup.add(rdoPCS);
        
        JLabel lblCategory = new JLabel("Category :");
		lblCategory.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblCategory.setBounds(72, 317, 106, 43);
		contentPane.add(lblCategory);
		//CATEGORY BUTTON
		JRadioButton rdoAppliances = new JRadioButton("Appliances");
		rdoAppliances.setBounds(163, 308, 82, 23);
		contentPane.add(rdoAppliances);
		
		JRadioButton rdoBeverages = new JRadioButton("Beverages");
		rdoBeverages.setBounds(252, 308, 82, 23);
		contentPane.add(rdoBeverages);
		
		JRadioButton rdoCondiments = new JRadioButton("Condiments");
		rdoCondiments.setBounds(163, 340, 89, 23);
		contentPane.add(rdoCondiments);
		
		JRadioButton rdoGrain = new JRadioButton("Grain");
		rdoGrain.setBounds(252, 340, 65, 23);
		contentPane.add(rdoGrain);
		
		JRadioButton rdoMeat = new JRadioButton("Meat");
		rdoMeat.setBounds(329, 340, 89, 23);
		contentPane.add(rdoMeat);
		
		JRadioButton rdoUtensils = new JRadioButton("Utensils");
		rdoUtensils.setBounds(431, 308, 89, 23);
		contentPane.add(rdoUtensils);
		
		JRadioButton rdoFurniture = new JRadioButton("Furniture");
		rdoFurniture.setBounds(340, 308, 89, 23);
		contentPane.add(rdoFurniture);
		// button group
		ButtonGroup buttonGroupCategory = new ButtonGroup();
		
		buttonGroupCategory.add(rdoAppliances);
		buttonGroupCategory.add(rdoBeverages);
		buttonGroupCategory.add(rdoCondiments);
		buttonGroupCategory.add(rdoGrain);
		buttonGroupCategory.add(rdoMeat);
		buttonGroupCategory.add(rdoUtensils);
		buttonGroupCategory.add(rdoFurniture);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.setBounds(37, 430, 89, 23);
		contentPane.add(btnBack);
		
		JButton btnAddNewProduct1 = new JButton("ADD");
		btnAddNewProduct1.setBackground(new Color(51, 179, 100));
		btnAddNewProduct1.setBounds(251, 200, 133, 57);
		contentPane.add(btnAddNewProduct1);
		btnBack.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				dispose();
			}
			
		});
//		-----------------ADDING TO DATABASE--------------------------------------------------------------
		JButton btnAddNewProduct = new JButton("ADD");
		btnAddNewProduct1.setBounds(251, 370, 133, 43);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/addbg.png")).getImage();
		
		txtPrice = new JTextField();
		txtPrice.setColumns(10);
		txtPrice.setBounds(317, 224, 191, 36);
		contentPane.add(txtPrice);
		
		JLabel lblAddBg = new JLabel("");
		lblAddBg.setIcon(new ImageIcon(bg));
		lblAddBg.setBounds(0, 0, 624, 469);
		contentPane.add(lblAddBg);

		btnAddNewProduct1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int productID = Integer.parseInt(txtProductID.getText());
				String productName = txtProductName.getText();
				int productQuantity = Integer.parseInt(txtQuantity.getText());
				int productPrice = Integer.parseInt(txtPrice.getText());
				String unit = "";
				try {
				    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
				    // Determine the unit based on the selected radio button
				    if (rdoKG.isSelected()) {
				        unit = "KG";
				    } else if (rdoPCS.isSelected()) {
				        unit = "PC";
				    } else {
				        // Handle the case where neither radio button is selected
				        JOptionPane.showMessageDialog(btnAddNewProduct, "Please select a unit (Kilograms or Pieces).");
				        return;
				    }
				    String category = "";
				    if (rdoAppliances.isSelected()) {
				    	category = "appliances";
				    }else if (rdoBeverages.isSelected()) {
				    	category = "beverages";
				    }else if (rdoCondiments.isSelected()) {
				    	category = "condiments";
				    }else if (rdoGrain.isSelected()) {
				    	category = "grain";
				    }else if (rdoMeat.isSelected()) {
				    	category = "meat";
				    }else if (rdoUtensils.isSelected()) {
				    	category = "utensil";
				    }else if (rdoFurniture.isSelected()) {
				    	category = "furniture";
				    }else {
				        // Handle the case where neither radio button is selected
				        JOptionPane.showMessageDialog(btnAddNewProduct, "Please select a category.");
				        return;
				    }
				    if(productID < 0)  {
				    	JOptionPane.showMessageDialog(null, "Error : Please Enter a not negative Product ID");
				    	return;
				    }
				    // Use PreparedStatement to insert data with parameters
				    String query = "INSERT INTO products (product_id, product_name, quantity, price_php_perPiece, unit, category) VALUES (?, ?, ?, ?, ?, ?)";
				    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				        preparedStatement.setInt(1, productID);
				        preparedStatement.setString(2, productName);
				        preparedStatement.setInt(3, productQuantity);
				        preparedStatement.setInt(4,productPrice);
				        preparedStatement.setString(5, unit);
				        preparedStatement.setString(6, category);
				        

				        int rowsAffected = preparedStatement.executeUpdate();

				        if (rowsAffected == 0) {
				            JOptionPane.showMessageDialog(btnAddNewProduct, "This Product is already exists");
				        } else {
				            JOptionPane.showMessageDialog(btnAddNewProduct, "New Product successfully inserted!");
				        }
				    }
				    connection.close();
				} catch (Exception exception) {
				    exception.printStackTrace();
				}	
			}
			});
	}
}
