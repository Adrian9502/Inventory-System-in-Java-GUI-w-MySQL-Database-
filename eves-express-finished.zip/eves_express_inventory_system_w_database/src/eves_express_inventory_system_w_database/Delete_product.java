package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class Delete_product extends JFrame {

	private JPanel contentPane;
	private JTextField txtDeleteProduct;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Delete_product frame = new Delete_product();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Delete_product() {
		setTitle("Eve's Express - Delete Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 453, 253);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtDeleteProduct = new JTextField();
		txtDeleteProduct.setBounds(179, 81, 200, 38);
		contentPane.add(txtDeleteProduct);
		txtDeleteProduct.setColumns(10);
		
		JButton btnDel = new JButton("DELETE");
		btnDel.setBackground(new Color(51, 179, 100));
		btnDel.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnDel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
		            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
		            
		            String productName = txtDeleteProduct.getText();
		            
		            // Use PreparedStatement to delete a row based on product name
		            String deleteQuery = "DELETE FROM products WHERE product_name = ?";
		            
		            try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
		                preparedStatement.setString(1, productName);
		                
		                int rowsAffected = preparedStatement.executeUpdate();

		                if (rowsAffected == 0) {
		                    JOptionPane.showMessageDialog(null, "No matching product name found for deletion. \nProduct Name : "+productName+ " Not found");
		                } else {
		                    JOptionPane.showMessageDialog(null, "Product : " + productName +" is successfully deleted!");
		                }
		            }
		            
		            connection.close();
		        } catch (Exception exception) {
		            exception.printStackTrace();
		        }
				
			}
		});
		btnDel.setBounds(182, 139, 114, 39);
		contentPane.add(btnDel);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBack.setBounds(52, 183, 89, 23);
		contentPane.add(btnBack);
		
		JLabel lblDeletebg = new JLabel("");
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/deletebg.png")).getImage();
		lblDeletebg.setIcon(new ImageIcon(bg));
		lblDeletebg.setBounds(0, 0, 439, 216);
		contentPane.add(lblDeletebg);
	}

}
