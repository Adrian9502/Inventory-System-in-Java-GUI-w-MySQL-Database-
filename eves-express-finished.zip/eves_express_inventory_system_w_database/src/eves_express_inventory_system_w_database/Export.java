package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.UIManager;

public class Export extends JFrame {

	private JPanel contentPane;
	private JTextField txtQuantity;
	private JTextField txtProductName;
	private JLabel bgEX;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Export frame = new Export();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Export() {
		setTitle("Eve's Express - Export Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 460, 257);
		contentPane = new JPanel();
		contentPane.setBackground(UIManager.getColor("Button.disabledShadow"));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBack.setBounds(10, 187, 89, 23);
		contentPane.add(btnBack);
		
		JButton btnExport = new JButton("EXPORT");
		btnExport.setBackground(new Color(51, 179, 100));
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

					try {
			            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
			            
			            String productName = txtProductName.getText();
			            String quantityText = txtQuantity.getText();

			            if (productName.isEmpty() || quantityText.isEmpty()) {
			                JOptionPane.showMessageDialog(btnExport, "Please enter product name and quantity.");
			            } 
			               
			            int addQuantity = Integer.parseInt(quantityText);

			            // Retrieve the old quantity before updating
			            int oldQuantity = getOldQuantityFromDatabase(productName, connection);
			           
			            // Use PreparedStatement to update quantity for a product
			            String updateQuery = "UPDATE products SET quantity = quantity - ? WHERE product_name = ?";

			            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
			                preparedStatement.setInt(1, addQuantity);
			                preparedStatement.setString(2, productName);
			                
			                int rowsAffected = preparedStatement.executeUpdate();

			                if (rowsAffected == 0) {
			                    JOptionPane.showMessageDialog(btnExport, "No matching product found for importing.");
			                } else {
			                	int newQuantity = getNewQuantityFromDatabase(productName, connection);
			                	// show the old and new quantity 
			                    JOptionPane.showMessageDialog(btnExport, "Old Quantity : "+oldQuantity +"\n New Quantity : "+newQuantity);
			                }
			            }
			            
			            connection.close();
			        } catch (Exception exception) {
			            exception.printStackTrace();
			        }
			    }

				private boolean productExistsInDatabase(String productName, Connection connection) {
				    String query = "SELECT COUNT(*) AS count FROM products WHERE product_name = ?";
				    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				        preparedStatement.setString(1, productName);
				        try (ResultSet resultSet = preparedStatement.executeQuery()) {
				            if (resultSet.next()) {
				                int count = resultSet.getInt("count");
				                return count > 0; // Product exists if count is greater than 0
				            }
				        }
				    } catch (Exception e) {
				        e.printStackTrace();
				    }
				    return false; // In case of an exception or other error, assume the product doesn't exist
				}

				private int getOldQuantityFromDatabase(String productName, Connection connection) {
				    try {
				        String query = "SELECT quantity FROM products WHERE product_name = ?";
				        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				            preparedStatement.setString(1, productName);
				            try (ResultSet resultSet = preparedStatement.executeQuery()) {
				                if (resultSet.next()) {
				                    return resultSet.getInt("quantity");
				                } else {
				                    // Product not found in the database
				                    JOptionPane.showMessageDialog(null, "Product not found in the database.");
				                    return -1; // Or any other value that indicates the product was not found
				                }
				            }
				        }
				    } catch (Exception e) {
				        e.printStackTrace();
				        JOptionPane.showMessageDialog(null, "Error retrieving quantity from the database: " + e.getMessage());
				        return -1; // Or any other value indicating an error
				    }
				}

				private int getNewQuantityFromDatabase(String productName, Connection connection) throws Exception {
				    String query = "SELECT quantity FROM products WHERE product_name = ?";
				    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				        preparedStatement.setString(1, productName);
				        try (ResultSet resultSet = preparedStatement.executeQuery()) {
				            if (resultSet.next()) {
				                return resultSet.getInt("quantity");
				            }
				        }
				    }
				    throw new RuntimeException("Product not found in the database");
				}
		});
		btnExport.setBounds(322, 161, 106, 40);
		contentPane.add(btnExport);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(250, 120, 164, 29);
		contentPane.add(txtQuantity);
		
		txtProductName = new JTextField();
		txtProductName.setColumns(10);
		txtProductName.setBounds(250, 72, 164, 29);
		contentPane.add(txtProductName);
		
		bgEX = new JLabel("");
		
		bgEX.setBounds(0, 0, 446, 243);
		contentPane.add(bgEX);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/item.png")).getImage();
		bgEX.setIcon(new ImageIcon(bg));
		
		
		
		
		
	}
}
