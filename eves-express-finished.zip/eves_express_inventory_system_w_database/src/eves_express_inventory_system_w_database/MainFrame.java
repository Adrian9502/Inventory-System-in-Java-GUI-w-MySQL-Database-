package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.SystemColor;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private JLabel bgMF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setTitle("Eve's Express - Silog Street");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\John Adrian Bonto\\OneDrive\\Desktop\\oop-finals\\images\\main.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1075, 799);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnExport = new JButton("EXPORT");
		btnExport.setForeground(new Color(255, 255, 255));
		btnExport.setBackground(Color.BLACK);
		btnExport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Export export = new Export();
				export.setVisible(true);
				export.setLocationRelativeTo(null);
			}
		});
		
		
		btnExport.setBounds(676, 319, 179, 79);
		contentPane.add(btnExport);
		
		JButton btnImport = new JButton("IMPORT");
		btnImport.setForeground(new Color(255, 255, 255));
		btnImport.setBackground(Color.BLACK);
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Import import1 = new Import();
				import1.setVisible(true);
				import1.setLocationRelativeTo(null);
			}
		});
		btnImport.setBounds(467, 318, 187, 79);
		contentPane.add(btnImport);
		
		JButton btnAddNew = new JButton("ADD NEW PRODUCT");
		btnAddNew.setBackground(new Color(51, 179, 100));
		btnAddNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Add_new_product addNewItem = new Add_new_product();
				 addNewItem.setVisible(true);
				 addNewItem.setLocationRelativeTo(null);
			}
		});
		btnAddNew.setBounds(470, 430, 395, 80);
		contentPane.add(btnAddNew);
		
		JButton btnDelete = new JButton("DELETE PRODUCT");
		btnDelete.setBackground(new Color(51, 179, 100));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Delete_product delete = new Delete_product();
				delete.setVisible(true);
				delete.setLocationRelativeTo(null);
			}
		});
		btnDelete.setBounds(469, 550, 395, 77);
		contentPane.add(btnDelete);
		
		JButton btnView = new JButton("VIEW");
//		btnView.setIcon(new ImageIcon(MainFrame.class.getResource("/icons/btnview.png")));
		btnView.setForeground(new Color(255, 255, 255));
		btnView.setBackground(Color.BLACK);
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				View view = new View();
				view.setVisible(true);
				view.setLocationRelativeTo(null);
			}
		});
		btnView.setBounds(143, 565, 164, 60);
		contentPane.add(btnView);
		
		bgMF = new JLabel("");
		bgMF.setBackground(Color.WHITE);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/mainframebg.png")).getImage();
		bgMF.setIcon(new ImageIcon(bg));
		bgMF.setBounds(0, 0, 1075, 799);
		contentPane.add(bgMF);
		
		
		
	
	}
}
