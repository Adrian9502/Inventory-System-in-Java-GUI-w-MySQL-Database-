package eves_express_inventory_system_w_database;

import java.awt.EventQueue;
import javax.swing.text.NumberFormatter;


import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.text.NumberFormat;
import java.awt.event.ActionEvent;
import javax.swing.JRadioButton;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import java.awt.Color;

public class adminRegister extends JFrame {

	private JPanel contentPane;
	private JTextField txtFname;
	private JTextField txtLname;
	private JTextField txtEmail;
	private JTextField txtAge;
	private JTextField txtUsername;
	private JPasswordField txtPassword;
	private ButtonGroup buttonGroup;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminRegister frame = new adminRegister();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminRegister() {
		setTitle("Eve's Express - Admin Register");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 509, 345);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtFname = new JTextField();
		txtFname.setBounds(90, 71, 128, 23);
		contentPane.add(txtFname);
		txtFname.setColumns(10);
		
		txtLname = new JTextField();
		txtLname.setColumns(10);
		txtLname.setBounds(279, 71, 119, 23);
		contentPane.add(txtLname);
		
		txtEmail = new JTextField();
		txtEmail.setColumns(10);
		txtEmail.setBounds(279, 137, 128, 23);
		contentPane.add(txtEmail);
		
		txtAge = new JTextField();
		txtAge.setColumns(10);
		txtAge.setBounds(90, 137, 128, 23);
		contentPane.add(txtAge);
		
		JRadioButton rdoStaff = new JRadioButton("Staff");
		rdoStaff.setBounds(152, 231, 66, 23);
		contentPane.add(rdoStaff);
		
		JRadioButton rdoManager = new JRadioButton("Manager");
		rdoManager.setBounds(220, 231, 75, 23);
		contentPane.add(rdoManager);
		
		buttonGroup = new ButtonGroup();
        buttonGroup.add(rdoStaff);
        buttonGroup.add(rdoManager);
		
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(new Color(51, 179, 100));
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//get the textfield
				String userName = txtUsername.getText();
				@SuppressWarnings("deprecation")
				String password = txtPassword.getText();
				String firstName = txtFname.getText();
				String lastName = txtLname.getText();
				String email = txtEmail.getText();
				int age = 0;
				
				try {
				    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");

				    //check if email is valid
				    if (!(email.endsWith("@gmail.com"))) {
				    	JOptionPane.showMessageDialog(btnRegister, "Please enter a valid Email");
					       return ;
				    }
				    try {
				     age = Integer.parseInt(txtAge.getText());
				     
				        if (!(age >= 1 && age <= 110)) {
				        	JOptionPane.showMessageDialog(btnRegister, "Please enter a valid Age");
				            return;
				        }
				    } catch (NumberFormatException e1) {
				        // Handle the case where txtAge.getText() is not a valid integer
				    	JOptionPane.showMessageDialog(btnRegister, "Please enter a valid Age");
			            return;
				    }

				    
				    String position = "";

					if (rdoStaff.isSelected()) {
				    	position = "staff";
				    } else if (rdoManager.isSelected()) {
				    	position = "manager";
				    } else {
				        // Handle the case where neither radio button is selected
				        JOptionPane.showMessageDialog(btnRegister, "Please select a position.");
				        return;
				    }

				    // Use PreparedStatement to insert data with parameters
				    String query = "INSERT INTO admin (username, password, firstName, lastName, email, age, position) VALUES (?, ?, ?, ?, ? ,? ,?)";
				    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				        preparedStatement.setString(1, userName);
				        preparedStatement.setString(2, password);
				        preparedStatement.setString(3, firstName);
				        preparedStatement.setString(4, lastName);
				        preparedStatement.setString(5, email);
				        preparedStatement.setInt(6, age);
				        preparedStatement.setString(7, position);

				        int rowsAffected = preparedStatement.executeUpdate();

				        if (rowsAffected == 0) {
				            JOptionPane.showMessageDialog(btnRegister, "This Admin is already exists");
				        } else {
				            JOptionPane.showMessageDialog(btnRegister, "Admin Registration Successful!");
				        }
				    }
				    connection.close();
				} catch (Exception exception) {
				    exception.printStackTrace();
				}	

			}
		});
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnRegister.setBounds(350, 256, 96, 35);
		contentPane.add(btnRegister);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnBack.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnBack.setBounds(23, 262, 66, 23);
		contentPane.add(btnBack);
		
		txtUsername = new JTextField();
		txtUsername.setColumns(10);
		txtUsername.setBounds(85, 201, 133, 23);
		contentPane.add(txtUsername);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(279, 201, 128, 23);
		contentPane.add(txtPassword);
		
		JLabel lblbg = new JLabel("");
		lblbg.setBounds(0, 0, 493, 307);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/adminbglast.png")).getImage();
		lblbg.setIcon(new ImageIcon(bg));
		contentPane.add(lblbg);
		
		
	}
}
