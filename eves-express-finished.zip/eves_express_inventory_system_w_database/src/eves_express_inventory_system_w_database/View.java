package eves_express_inventory_system_w_database;

import java.awt.EventQueue;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.swing.JScrollPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.RowSorter;
import javax.swing.SortOrder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.Color;


public class View extends JFrame {

	private JPanel contentPane;
	private JTextField txtSearch;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View frame = new View();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public View() {
		setTitle("Eve's Express - View Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1041, 633);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.setBackground(new Color(51, 179, 100));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton.setBounds(103, 559, 89, 23);
		contentPane.add(btnNewButton);
		
		txtSearch = new JTextField();
		txtSearch.setBounds(294, 96, 176, 34);
		contentPane.add(txtSearch);
		txtSearch.setColumns(10);
		
		DefaultTableModel model = new DefaultTableModel();
        JTable tblData = new JTable(model);

        // Add columns to the table model
        model.addColumn("Product ID");
        model.addColumn("Product Name");
        model.addColumn("Quantity");
        model.addColumn("Price in Php");
        model.addColumn("Unit");
        model.addColumn("Category");

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
            String selectQuery = "SELECT * FROM products";

            try (PreparedStatement preparedStatement = connection.prepareStatement(selectQuery);
                 ResultSet resultSet = preparedStatement.executeQuery()) {

                while (resultSet.next()) {
                    // Retrieve data from the result set
                    int productId = resultSet.getInt("product_id");
                    String productName = resultSet.getString("product_name");
                    int quantity = resultSet.getInt("quantity");
                    int price = resultSet.getInt("price_php_perPiece");
                    String unit = resultSet.getString("unit");
                    String category = resultSet.getString("category");

                    // Add a row to the table model
                    model.addRow(new Object[]{productId, productName, quantity, price, unit, category});
                }
            }

            connection.close();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        TableRowSorter<TableModel> rowSorter = new TableRowSorter<>(tblData.getModel());
        tblData.setRowSorter(rowSorter);
        
        JScrollPane scrollPane = new JScrollPane(tblData);
        scrollPane.setBounds(124, 146, 832, 402);
        contentPane.add(scrollPane);
        
        JButton btnSearch = new JButton("Search");
        btnSearch.setBackground(new Color(51, 179, 100));
        btnSearch.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		String search = txtSearch.getText();
        		
        		if (search.trim().length() == 0) {
        		    rowSorter.setRowFilter(null);
        		} else {
        		    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + search));

        		    // Check if any rows are found
        		    if (tblData.getRowCount() == 0) {
        		        JOptionPane.showMessageDialog(null, "No matching product found for: " + search);
        		        
        		    } else {
        		        JOptionPane.showMessageDialog(null, search + " Found Successfully!");
        		    }
        		}

        	}
        });
        
        JButton btnASC = new JButton("Ascending");
        btnASC.setBackground(new Color(51, 179, 100));
        btnASC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	rowSorter.setSortKeys(null); // Clear any existing sort keys
            	rowSorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.ASCENDING))); 
            }
        });
		btnASC.setBounds(712, 95, 101, 34);
		contentPane.add(btnASC);
		
		JButton btnDESC = new JButton("Descending");
		btnDESC.setBackground(new Color(51, 179, 100));
		btnDESC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	rowSorter.setSortKeys(null); // Clear any existing sort keys
            	rowSorter.setSortKeys(List.of(new RowSorter.SortKey(0, SortOrder.DESCENDING)));
            }
        });
		btnDESC.setBounds(823, 95, 95, 34);
		contentPane.add(btnDESC);
        
        btnSearch.setBounds(480, 95, 89, 34);
        contentPane.add(btnSearch);
        
        JLabel lblNewLabel = new JLabel("Search :");
        lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
        lblNewLabel.setBounds(209, 98, 75, 24);
        contentPane.add(lblNewLabel);
        
        JLabel lblNewLabel_2 = new JLabel("Sort by Product ID :");
        lblNewLabel_2.setBounds(579, 96, 123, 34);
        contentPane.add(lblNewLabel_2);
        
        JLabel lblViewBg = new JLabel("");
        Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/viewbg.png")).getImage();
		lblViewBg.setIcon(new ImageIcon(bg));
        lblViewBg.setBounds(0, 0, 1027, 596);
        contentPane.add(lblViewBg);
}
	
}
