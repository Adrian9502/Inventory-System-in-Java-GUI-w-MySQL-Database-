package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import java.awt.Label;
import java.awt.Color;

public class Import extends JFrame {

	private JPanel contentPane;
	private JTextField txtProductName;
	private JTextField txtQuantity;
	private JLabel lblNav;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Import frame = new Import();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Import() {
		setTitle("Eve's Express - Import Product");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 454, 257);
		contentPane = new JPanel();
		contentPane.setBackground(Color.WHITE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		Image nav = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/importbg.png")).getImage();
		txtProductName = new JTextField();
		txtProductName.setBounds(255, 68, 164, 29);
		contentPane.add(txtProductName);
		txtProductName.setColumns(10);
		
		txtQuantity = new JTextField();
		txtQuantity.setColumns(10);
		txtQuantity.setBounds(255, 107, 164, 29);
		contentPane.add(txtQuantity);
		
		
//		ADD A CONNECTION AND A SCRIPT TO RUN IN DATABASE
		JButton btnImport = new JButton("IMPORT");
		btnImport.setBackground(new Color(51, 179, 100));
		btnImport.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				try {
		            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");
		            
		            String productName = txtProductName.getText();
		            String quantityText = txtQuantity.getText();

		            if (productName.isEmpty() || quantityText.isEmpty()) {
		                JOptionPane.showMessageDialog(btnImport, "Please enter product name and quantity.");
		            } 
		               
		            int addQuantity = Integer.parseInt(quantityText);

		            // Retrieve the old quantity before updating
		            int oldQuantity = getOldQuantityFromDatabase(productName, connection);
		           
		            // Use PreparedStatement to update quantity for a product
		            String updateQuery = "UPDATE products SET quantity = quantity + ? WHERE product_name = ?";

		            try (PreparedStatement preparedStatement = connection.prepareStatement(updateQuery)) {
		                preparedStatement.setInt(1, addQuantity);
		                preparedStatement.setString(2, productName);
		                
		                int rowsAffected = preparedStatement.executeUpdate();

		                if (rowsAffected == 0) {
		                    JOptionPane.showMessageDialog(btnImport, "No matching product found for importing.");
		                } else {
		                	int newQuantity = getNewQuantityFromDatabase(productName, connection);
		                	// show the old and new quantity 
		                    JOptionPane.showMessageDialog(btnImport, "Old Quantity : "+oldQuantity +"\n New Quantity : "+newQuantity);
		                }
		            }
		            
		            connection.close();
		        } catch (Exception exception) {
		            exception.printStackTrace();
		        }
		    }

			private boolean productExistsInDatabase(String productName, Connection connection) {
			    String query = "SELECT COUNT(*) AS count FROM products WHERE product_name = ?";
			    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			        preparedStatement.setString(1, productName);
			        try (ResultSet resultSet = preparedStatement.executeQuery()) {
			            if (resultSet.next()) {
			                int count = resultSet.getInt("count");
			                return count > 0; // Product exists if count is greater than 0
			            }
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			    }
			    return false; // In case of an exception or other error, assume the product doesn't exist
			}

			private int getOldQuantityFromDatabase(String productName, Connection connection) {
			    try {
			        String query = "SELECT quantity FROM products WHERE product_name = ?";
			        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			            preparedStatement.setString(1, productName);
			            try (ResultSet resultSet = preparedStatement.executeQuery()) {
			                if (resultSet.next()) {
			                    return resultSet.getInt("quantity");
			                } else {
			                    // Product not found in the database
			                    JOptionPane.showMessageDialog(null, "Product not found in the database.");
			                    return -1; // Or any other value that indicates the product was not found
			                }
			            }
			        }
			    } catch (Exception e) {
			        e.printStackTrace();
			        JOptionPane.showMessageDialog(null, "Error retrieving quantity from the database: " + e.getMessage());
			        return -1; // Or any other value indicating an error
			    }
			}

			private int getNewQuantityFromDatabase(String productName, Connection connection) throws Exception {
			    String query = "SELECT quantity FROM products WHERE product_name = ?";
			    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
			        preparedStatement.setString(1, productName);
			        try (ResultSet resultSet = preparedStatement.executeQuery()) {
			            if (resultSet.next()) {
			                return resultSet.getInt("quantity");
			            }
			        }
			    }
			    throw new RuntimeException("Product not found in the database");
			}
			
		});
		btnImport.setBounds(324, 170, 106, 40);
		contentPane.add(btnImport);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.setBounds(10, 187, 89, 23);
		btnBack.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Code to execute when the Back button is clicked
                // For example, you might want to close the current frame or go back to the previous screen.
                dispose(); // Close the current frame
            }
        });
		contentPane.add(btnBack);
		
		lblNav = new JLabel("");
		lblNav.setIcon(new ImageIcon(nav));
		lblNav.setBounds(0, 0, 440, 220);
		contentPane.add(lblNav);
		
	}
}
