package eves_express_inventory_system_w_database;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;

public class Login extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setTitle("Eve's Express - Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 609, 424);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnCustomer = new JButton("Customer");
		btnCustomer.setBackground(new Color(51, 179, 100));
		btnCustomer.setBounds(89, 252, 190, 57);
		btnCustomer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Order customer = new Order();
				customer.setVisible(true);
				customer.setLocationRelativeTo(null);
			}
		});
		contentPane.add(btnCustomer);
		JButton btnAdmin = new JButton("Admin");
		btnAdmin.setBackground(new Color(51, 179, 100));
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				adminLogin admin = new adminLogin();
				admin.setVisible(true);
				admin.setLocationRelativeTo(null);
			}
		});
		btnAdmin.setBounds(319, 251, 190, 57);
		contentPane.add(btnAdmin);
		
		JLabel lblbg = new JLabel("");
		lblbg.setBounds(-1, -4, 593, 387);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/startbg.png")).getImage();
		lblbg.setIcon(new ImageIcon(bg));
		contentPane.add(lblbg);
	}
}
