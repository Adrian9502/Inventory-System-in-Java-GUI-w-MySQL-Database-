package eves_express_inventory_system_w_database;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Color;

public class adminLogin extends JFrame {

	private JPanel contentPane;
	private JTextField txtUsername;
	private JPasswordField txtPassword;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					adminLogin frame = new adminLogin();
					frame.setVisible(true);
					frame.setLocationRelativeTo(null);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public adminLogin() {
		setTitle("Eve's Express - Admin Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setBackground(new Color(51, 179, 100));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				    Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/eves_express", "root", "");

				    //get the credentials
				    String username = txtUsername.getText();
				    String enteredPassword = txtPassword.getText();

				    if (username.isEmpty() || enteredPassword.isEmpty()) {
				        JOptionPane.showMessageDialog(btnLogin, "Please enter Username and Password ");
				        return;
				    }
				    // Use PreparedStatement to select data with parameters
				    String query = "SELECT password FROM admin WHERE username = ?";
				    try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
				        preparedStatement.setString(1, username);

				        ResultSet resultSet = preparedStatement.executeQuery();

				        if (resultSet.next()) {
				            // Retrieve the password from the database
				            String storedPassword = resultSet.getString("password");
				            // Check if the entered password matches the stored password
				            if (enteredPassword.equals(storedPassword)) {
				                JOptionPane.showMessageDialog(btnLogin, "Login Successful!");
				                dispose();
				                MainFrame main = new MainFrame();
				                main.setVisible(true);
				            } else {
				                JOptionPane.showMessageDialog(btnLogin, "Invalid Password!");
				            }
				        } else {
				            JOptionPane.showMessageDialog(btnLogin, "User not found!");
				        }
				    }
				    connection.close();
				} catch (Exception exception) {
				    exception.printStackTrace();
				}	
			}
		});
		btnLogin.setBounds(189, 169, 116, 45);
		contentPane.add(btnLogin);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.setBackground(new Color(51, 179, 100));
		btnRegister.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				adminRegister register = new adminRegister();
				register.setVisible(true);
				register.setLocationRelativeTo(null);
			}
		});
		btnRegister.setBounds(20, 227, 89, 23);
		contentPane.add(btnRegister);
		
		txtUsername = new JTextField();
		txtUsername.setBounds(189, 91, 124, 23);
		contentPane.add(txtUsername);
		txtUsername.setColumns(10);
		
		JButton btnBack = new JButton("Back");
		btnBack.setBackground(new Color(51, 179, 100));
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();			}
		});
		btnBack.setBounds(346, 227, 78, 23);
		contentPane.add(btnBack);
		
		txtPassword = new JPasswordField();
		txtPassword.setBounds(189, 125, 124, 23);
		contentPane.add(txtPassword);
		
		JLabel lblbg = new JLabel("");
		lblbg.setBounds(0, 2, 434, 260);
		Image bg = new ImageIcon(this.getClass().getResource("/eves_express_inventory_system_w_database/images/loginbg.png")).getImage();
		lblbg.setIcon(new ImageIcon(bg));
		contentPane.add(lblbg);
	}
}
